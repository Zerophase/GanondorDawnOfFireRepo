﻿using UnityEngine;
using System.Collections;

public class ThirdPerson_Camera : MonoBehaviour 
{
    public static ThirdPerson_Camera Instance;

    private Transform TargetLookAt;

    public float Distance = 5.0f;
    public float DistanceMin = 3.0f;
    public float DistanceMax = 10.0f;
    public float DistanceSmooth = 0.05f;
    private float velocityDistance; //Set to 0f

    private float startDistance; //Distance after Validation of Distance
    private float desiredDistance;
    private Vector3 desiredPosition = Vector3.zero;
    private Vector3 position = Vector3.zero;

    public float X_MouseSensitivity = 5.0f;
    public float Y_MouseSensitivity = 5.0f;
    private float mouseX; //Rotates camera left or right
    private float mouseY; //Rotates camera up or down

    //TODO: Make nullable in case camera can't zoom
    public float MouseWheel_Sensitivity = 5.0f;
    public float Y_MinLimit = -40.0f;
    public float Y_MaxLimit = 80.0f;

    public float X_Smooth = 0.05f;
    public float Y_Smooth = 0.1f;
    private float velocityX = 0.0f;
    private float velocityY = 0.0f;
    private float velocityZ = 0.0f;

    public enum LookControls { UNLOCKED, LOCKED };
    public LookControls CameraControl = LookControls.LOCKED;

    public bool InvertMouseLook = false;

	void Awake() 
    {
        assignReferences();
	}

    private void assignReferences()
    {
        Instance = this;
    }

    public static void AssignMainCamera()
    {
        GameObject tempCamera;
        if (Camera.main != null)
            tempCamera = Camera.main.gameObject;
        else
        {
            tempCamera = new GameObject("MainCamera");
            tempCamera.AddComponent<Camera>();
            tempCamera.tag = "MainCamera";
        }
        
        if (!tempCamera.GetComponent<ThirdPerson_Camera>())
            tempCamera.AddComponent<ThirdPerson_Camera>();

        assignTargetLookAt(tempCamera);
    }

    private static void assignTargetLookAt(GameObject tempCamera)
    {
        GameObject targetLookAt = GameObject.Find("targetLookAt");
        if(targetLookAt == null)
        {
            targetLookAt = new GameObject("targetLookAt");
            targetLookAt.transform.position = Vector3.zero;
        }

        ThirdPerson_Camera myCamera = tempCamera.GetComponent<ThirdPerson_Camera>();
        myCamera.TargetLookAt = targetLookAt.transform;
    }

    void Start()
    {
        //Validates Input

        //TODO: Remove and push into Reset() if it makes sense in the end
        Distance = Mathf.Clamp(Distance, DistanceMin, DistanceMax);
        startDistance = Distance;

        Reset();
    }

    //Sets Initial Values and Resets camera if character dies, etc
    public void Reset()
    {
        mouseX = 0.0f; //behind character
        mouseY = 10.0f; //Just above character

        //TODO: See if refactoring desiredDistance to be local to handlePlayerInput makes line below irrelevant
        desiredDistance = Distance = startDistance; //Makes sure smoothing doesn't begin immediately
    }

    void LateUpdate()
    {
        //Update method that happens after a regular update

        //Look for a TargetLookAt and make sure it isn't null
        if (TargetLookAt == null)
            return;
       
        handlePlayerInput(); 
        
        calculateDesiredPosition();

        updatePosition();
    }

    //Processes Smoothing for camera movement
    private void updatePosition()
    {
        //Done this way to allow the x and y position to smooth independently
        var posX = Mathf.SmoothDamp(position.x, desiredPosition.x, ref velocityX, X_Smooth);
        var posY = Mathf.SmoothDamp(position.y, desiredPosition.y, ref velocityY, Y_Smooth);
        var posZ = Mathf.SmoothDamp(position.z, desiredPosition.z, ref velocityZ, X_Smooth);
        position = new Vector3(posX, posY, posZ);

        transform.position = position;

        transform.LookAt(TargetLookAt);
    }

    //Uses data from HandlePlayerInput to update Position
    private void calculateDesiredPosition()
    {
        //Smoothes the curve the camera is moving along
        Distance = Mathf.SmoothDamp(Distance, desiredDistance, ref velocityDistance, DistanceSmooth);

        desiredPosition = calculatePosition(mouseY, mouseX, Distance);
    }

    //Converts from mouse space to 3D space
    private Vector3 calculatePosition(float rotationX, float rotationY, float distance)
    {
        Vector3 direction = new Vector3(0, 0, -distance);
        Quaternion rotation = Quaternion.Euler(rotationX, rotationY, 0); //TODO: play with rolling the camera by setting the z value
        return (TargetLookAt.position + (rotation * direction));
    }

    //Handles Player Input, Mouse Input, and processing input
    void handlePlayerInput()
    {
        var deadZone = 0.01f;

        if (Input.GetMouseButton(1) && CameraControl == LookControls.LOCKED)
        {
            //takes mouse input
            mouseX += Input.GetAxis("Mouse X") * X_MouseSensitivity;
            mouseY -= Input.GetAxis("Mouse Y") * Y_MouseSensitivity;
            //look();
        }
        else if(CameraControl == LookControls.UNLOCKED)
        {
            //look();
        }

        mouseY = Helper.ClampAngle(mouseY, Y_MinLimit, Y_MaxLimit);

        //Applies sensitivity value of mouse wheel
        if (Input.GetAxis("Mouse ScrollWheel") < -deadZone || Input.GetAxis("Mouse ScrollWheel") > deadZone)
            desiredDistance = Mathf.Clamp(Distance - Input.GetAxis("Mouse ScrollWheel") * MouseWheel_Sensitivity, 
                                    DistanceMin, DistanceMax);
        
        //Apply mouseWheel_sensitivity
        //Subtact the value from current distance
        //clamps this information at the end
    }

    //TODO: Make Return vector 2 at end once everything else is working.
    private float look()
    {
        if(InvertMouseLook)
        {
            //Multiply mouse values by -1
        }

        return 0.0f;
    }
}
