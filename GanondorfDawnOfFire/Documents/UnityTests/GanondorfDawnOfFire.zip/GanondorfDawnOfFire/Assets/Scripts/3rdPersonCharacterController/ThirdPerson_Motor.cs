﻿using UnityEngine;
using System.Collections;

public class ThirdPerson_Motor : MonoBehaviour 
{
    public static ThirdPerson_Motor Instance;

    public float Speed = 10;
    public Vector3 Move { get; set; }

	void Awake() 
    {
        assignReferences();
	}
	
    private void assignReferences()
    {
        Instance = this;
    }

	public void UpdateMotor() 
    {
        snapCharacterToCameraFacing();

        processMotion();
	}

    private void processMotion()
    {
        Move = transform.TransformDirection(Move);

        if (Move.magnitude > 1)
            Move = Vector3.Normalize(Move);

        ThirdPerson_Controller.CharacterController.Move( Move *= (Speed * Time.deltaTime));
    }

    //TODO see if snapCharacterToCamerFacing should go in ThirdPerson_Camera
    private void snapCharacterToCameraFacing()
    {
        //if move vector x or z != 0 rotate character to camera facing
        if(Move.x != 0 || Move.z != 0)
            transform.rotation = Quaternion.Euler(transform.eulerAngles.x, 
                Camera.main.transform.eulerAngles.y, transform.eulerAngles.z);
    }
}
