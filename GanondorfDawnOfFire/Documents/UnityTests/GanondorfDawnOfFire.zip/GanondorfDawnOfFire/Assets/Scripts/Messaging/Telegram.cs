﻿using UnityEngine;
using System.Collections;

public struct Telegram
{
    int ID;
}
