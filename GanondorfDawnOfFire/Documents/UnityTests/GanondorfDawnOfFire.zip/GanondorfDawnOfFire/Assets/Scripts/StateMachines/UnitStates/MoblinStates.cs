﻿using UnityEngine;
using System.Collections;

public class MoblinGlobalState : IState<Moblin>
{
    private static MoblinGlobalState instance;
    public static MoblinGlobalState Instance
    {
        get { return instance ?? instance; }
        set { instance = value; }
    }
    public void Enter(Unit unit)
    {
        throw new System.NotImplementedException();
    }

    public void Execute(Unit unit)
    {
        throw new System.NotImplementedException();
    }

    public void Exit(Unit unit)
    {
        throw new System.NotImplementedException();
    }

    public void OnMessage(Unit unit, Telegram telegram)
    {
        throw new System.NotImplementedException();
    }
}
