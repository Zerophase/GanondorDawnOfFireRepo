﻿using UnityEngine;
using System.Collections;

public class StateMachine<T> where T : Unit
{
    private Unit owner;

    private IState<Unit> currentState;
    private IState<Unit> previousState;
    private IState<Unit> globalState;

    public IState<Unit> Set_currentState { set { currentState = value; } }
    public IState<Unit> Set_previousState { set { previousState = value; } }
    public IState<Unit> Set_globalState { set { globalState = value; } }

    public StateMachine(Unit unit)
    {
        owner = unit;

        currentState = null;
        previousState = null;
        globalState = null;
    }

    public void Update ()
    {
        if (globalState != null)
            globalState.Execute(owner);

        if (currentState != null)
            currentState.Execute(owner);
    }

    public void HandleMessage(Telegram telegram)
    {
        currentState.OnMessage(owner, telegram);

        if (globalState != null)
            globalState.OnMessage(owner, telegram);
    }

    public void ChangeState(IState<Unit> newState)
    {
        previousState = currentState;
        currentState.Exit(owner);

        currentState = newState;
        currentState.Enter(owner);
    }
}
