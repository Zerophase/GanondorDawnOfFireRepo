﻿using UnityEngine;
using System.Collections;

//TODO Define Telegram members

public interface IState<T> where T : Unit 
{
    void Enter(Unit unit);
    void Execute(Unit unit);
    void Exit(Unit unit);
    void OnMessage(Unit unit, Telegram telegram);
}
