﻿using UnityEngine;
using System.Collections;

public abstract class BaseUnit : MonoBehaviour 
{
}
