﻿using UnityEngine;
using System.Collections;

public class UnitMediator : Mediator {

    private Director director;

    private static int nextID = 0;

    protected Color unpicked;
    protected Color picked;

    [HideInInspector]
    public int ID;
    public virtual void Init(Director director)
    {
        this.director = director;
        gameObject.renderer.material.color = unpicked;

        ID = nextID++;
    }

    public void Picked()
    {
        this.director.Hovered(this);
    }
	
	// Update is called once per frame
    protected void Update () 
    {
        if (Picker.Instance.InSphere(gameObject))
        {
            gameObject.renderer.material.color = picked;
        }
        else if (gameObject.renderer.material.color == picked)
            gameObject.renderer.material.color = unpicked;
	}
}
