﻿using UnityEngine;
using System.Collections;

public abstract class Mediator : MonoBehaviour {

	
	// Update is called once per frame
	void Update () {
	
	}
}
