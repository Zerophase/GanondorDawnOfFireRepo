﻿using UnityEngine;
using System.Collections;

public class MoblinMediator : UnitMediator 
{
    public override void Init(Director director)
    {
        unpicked = Color.blue;
        picked = Color.red;
        base.Init(director);
    }
}
