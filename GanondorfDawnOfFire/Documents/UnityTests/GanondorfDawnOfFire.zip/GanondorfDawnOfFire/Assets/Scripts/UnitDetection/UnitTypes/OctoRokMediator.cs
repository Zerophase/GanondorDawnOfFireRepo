﻿using UnityEngine;
using System.Collections;

public class OctoRokMediator : UnitMediator 
{
    public override void Init(Director director)
    {
        unpicked = Color.black;
        picked = Color.green;

        base.Init(director);
    }
}
