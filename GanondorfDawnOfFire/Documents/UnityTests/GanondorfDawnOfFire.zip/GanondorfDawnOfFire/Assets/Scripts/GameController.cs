﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GameController : Director 
{

    List<UnitMediator> unitMediators = new List<UnitMediator>();
    private UnitMediator[] unitMediatorsToAdd;

    private ForwardDirection playerForward;

    public float TimeSinceCollision;

	void Start () 
    {
         unitMediatorsToAdd = GameObject.FindObjectsOfType<UnitMediator>();
         for (int i = 0; i < unitMediatorsToAdd.Length; i++)
         {
             unitMediatorsToAdd[i].Init(this);

             unitMediators.Add(unitMediatorsToAdd[i]);
         }

         Debug.Log("Units on Screen = " + unitMediators.Count);
         playerForward = GameObject.FindGameObjectWithTag("MainCamera").GetComponentInChildren<ForwardDirection>();
	}
	
	void Update () 
    {
        foreach (UnitMediator enemy in unitMediators)
        {
            if (playerForward.Hit().collider == enemy.collider)
            {
                //Debug.Log("Enemy ID = " + enemy.ID);
                enemy.Picked();
                TimeSinceCollision = 0;
            }
        }

        if (playerForward.Hit().collider != null)
        {
            if (playerForward.Hit().collider.GetComponent<UnitMediator>() == null)
            {
                waitToDeselect();
            }
        }
        else if (playerForward.Hit().collider == null)
        {
            waitToDeselect();
        }
	}

    private void waitToDeselect()
    {
        TimeSinceCollision += Time.deltaTime;
        if (TimeSinceCollision > .5f)
        {
            Picker.Instance.UpdateSpherePos();
            TimeSinceCollision = 0;
        }
    }
}
