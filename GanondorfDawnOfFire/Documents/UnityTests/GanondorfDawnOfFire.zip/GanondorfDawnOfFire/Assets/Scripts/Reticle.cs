﻿using UnityEngine;
using System.Collections;

public class Reticle : MonoBehaviour 
{
    ForwardDirection forwardDirection;

    Vector3 pos;
    Vector3 zOffSet = new Vector3(0, 0, 20);

    void Start ()
    {
        forwardDirection = GameObject.FindObjectOfType<ForwardDirection>();

    }
	// Update is called once per frame
	void Update () 
    {
        pos = new Vector3(forwardDirection.transform.position.x,
            forwardDirection.transform.position.y, forwardDirection.transform.position.z + zOffSet.z);
        gameObject.transform.position = pos;
        //gameObject.transform.forward = forwardDirection.transform.forward;
	}
}
