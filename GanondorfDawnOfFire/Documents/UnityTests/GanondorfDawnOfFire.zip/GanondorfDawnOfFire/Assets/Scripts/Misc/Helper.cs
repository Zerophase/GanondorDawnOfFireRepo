﻿using UnityEngine;

public static class Helper
{
    //Constrains angle to only be between 360 and 0
    public static float ClampAngle(float angle, float min, float max)
    {
        do
        {
            if (angle < -360)
                angle += 360;
            else if (angle > 360)
                angle -= 360;
        } while (angle < - 360 || angle > 360);
        //Then clamp and returns
        return Mathf.Clamp(angle, min, max);
    }
}
